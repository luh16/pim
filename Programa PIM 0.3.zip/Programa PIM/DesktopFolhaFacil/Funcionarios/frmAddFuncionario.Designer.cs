﻿namespace PrototipoRH.Funcionarios
{
    partial class frmAddFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.boxSalarioFunc = new System.Windows.Forms.GroupBox();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.boxCargoFunc = new System.Windows.Forms.GroupBox();
            this.txtCargoFunc = new System.Windows.Forms.TextBox();
            this.boxStatusFunc = new System.Windows.Forms.GroupBox();
            this.cboStatus = new System.Windows.Forms.ComboBox();
            this.boxCargaFunc = new System.Windows.Forms.GroupBox();
            this.txtCargaHorariaSemanal = new System.Windows.Forms.MaskedTextBox();
            this.boxCarteiraTrabFunc = new System.Windows.Forms.GroupBox();
            this.mskCarteiraTrabalho = new System.Windows.Forms.MaskedTextBox();
            this.boxPisFunc = new System.Windows.Forms.GroupBox();
            this.txtPis = new System.Windows.Forms.MaskedTextBox();
            this.boxDepartamentoFunc = new System.Windows.Forms.GroupBox();
            this.txtDepartamento = new System.Windows.Forms.TextBox();
            this.boxEmpresaFunc = new System.Windows.Forms.GroupBox();
            this.cbEmpresa = new System.Windows.Forms.ComboBox();
            this.boxRgFunc = new System.Windows.Forms.GroupBox();
            this.txtRg = new System.Windows.Forms.MaskedTextBox();
            this.boxDataNascFunc = new System.Windows.Forms.GroupBox();
            this.txtDataNascimento = new System.Windows.Forms.MaskedTextBox();
            this.boxTelefoneFunc = new System.Windows.Forms.GroupBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.boxEnderecoFunc = new System.Windows.Forms.GroupBox();
            this.txtEnderecoFuncionario = new System.Windows.Forms.TextBox();
            this.boxEmailFunc = new System.Windows.Forms.GroupBox();
            this.txtEMail = new System.Windows.Forms.TextBox();
            this.boxMatriculaFunc = new System.Windows.Forms.GroupBox();
            this.txtMatriculaFuncionario = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.boxDataAdmFunc = new System.Windows.Forms.GroupBox();
            this.mskDataAdmissao = new System.Windows.Forms.MaskedTextBox();
            this.boxCpfFunc = new System.Windows.Forms.GroupBox();
            this.mskCpf = new System.Windows.Forms.MaskedTextBox();
            this.boxNomeFunc = new System.Windows.Forms.GroupBox();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tBempresaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBempresaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.btnAddFuncionario = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.boxSalarioFunc.SuspendLayout();
            this.boxCargoFunc.SuspendLayout();
            this.boxStatusFunc.SuspendLayout();
            this.boxCargaFunc.SuspendLayout();
            this.boxCarteiraTrabFunc.SuspendLayout();
            this.boxPisFunc.SuspendLayout();
            this.boxDepartamentoFunc.SuspendLayout();
            this.boxEmpresaFunc.SuspendLayout();
            this.boxRgFunc.SuspendLayout();
            this.boxDataNascFunc.SuspendLayout();
            this.boxTelefoneFunc.SuspendLayout();
            this.boxEnderecoFunc.SuspendLayout();
            this.boxEmailFunc.SuspendLayout();
            this.boxMatriculaFunc.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.boxDataAdmFunc.SuspendLayout();
            this.boxCpfFunc.SuspendLayout();
            this.boxNomeFunc.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tBempresaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBempresaBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.boxSalarioFunc);
            this.groupBox1.Controls.Add(this.boxCargoFunc);
            this.groupBox1.Controls.Add(this.boxStatusFunc);
            this.groupBox1.Controls.Add(this.boxCargaFunc);
            this.groupBox1.Controls.Add(this.boxCarteiraTrabFunc);
            this.groupBox1.Controls.Add(this.boxPisFunc);
            this.groupBox1.Controls.Add(this.boxDepartamentoFunc);
            this.groupBox1.Controls.Add(this.boxEmpresaFunc);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 261);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1042, 215);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados Contratuais";
            // 
            // boxSalarioFunc
            // 
            this.boxSalarioFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxSalarioFunc.Controls.Add(this.txtSalarioBruto);
            this.boxSalarioFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxSalarioFunc.Location = new System.Drawing.Point(598, 38);
            this.boxSalarioFunc.Name = "boxSalarioFunc";
            this.boxSalarioFunc.Size = new System.Drawing.Size(130, 40);
            this.boxSalarioFunc.TabIndex = 22;
            this.boxSalarioFunc.TabStop = false;
            this.boxSalarioFunc.Text = "Salário Bruto:";
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(6, 14);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioBruto.TabIndex = 48;
            // 
            // boxCargoFunc
            // 
            this.boxCargoFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxCargoFunc.Controls.Add(this.txtCargoFunc);
            this.boxCargoFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxCargoFunc.Location = new System.Drawing.Point(9, 164);
            this.boxCargoFunc.Name = "boxCargoFunc";
            this.boxCargoFunc.Size = new System.Drawing.Size(295, 42);
            this.boxCargoFunc.TabIndex = 25;
            this.boxCargoFunc.TabStop = false;
            this.boxCargoFunc.Text = "Cargo:";
            // 
            // txtCargoFunc
            // 
            this.txtCargoFunc.Location = new System.Drawing.Point(6, 16);
            this.txtCargoFunc.Name = "txtCargoFunc";
            this.txtCargoFunc.Size = new System.Drawing.Size(273, 20);
            this.txtCargoFunc.TabIndex = 49;
            // 
            // boxStatusFunc
            // 
            this.boxStatusFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxStatusFunc.Controls.Add(this.cboStatus);
            this.boxStatusFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxStatusFunc.Location = new System.Drawing.Point(348, 164);
            this.boxStatusFunc.Name = "boxStatusFunc";
            this.boxStatusFunc.Size = new System.Drawing.Size(95, 42);
            this.boxStatusFunc.TabIndex = 26;
            this.boxStatusFunc.TabStop = false;
            this.boxStatusFunc.Text = "Status:";
            // 
            // cboStatus
            // 
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Location = new System.Drawing.Point(6, 16);
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.Size = new System.Drawing.Size(72, 21);
            this.cboStatus.TabIndex = 45;
            // 
            // boxCargaFunc
            // 
            this.boxCargaFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxCargaFunc.Controls.Add(this.txtCargaHorariaSemanal);
            this.boxCargaFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxCargaFunc.Location = new System.Drawing.Point(316, 103);
            this.boxCargaFunc.Name = "boxCargaFunc";
            this.boxCargaFunc.Size = new System.Drawing.Size(149, 47);
            this.boxCargaFunc.TabIndex = 24;
            this.boxCargaFunc.TabStop = false;
            this.boxCargaFunc.Text = "Carga Horária Semanal:";
            // 
            // txtCargaHorariaSemanal
            // 
            this.txtCargaHorariaSemanal.Location = new System.Drawing.Point(58, 19);
            this.txtCargaHorariaSemanal.Mask = "00";
            this.txtCargaHorariaSemanal.Name = "txtCargaHorariaSemanal";
            this.txtCargaHorariaSemanal.Size = new System.Drawing.Size(25, 20);
            this.txtCargaHorariaSemanal.TabIndex = 46;
            // 
            // boxCarteiraTrabFunc
            // 
            this.boxCarteiraTrabFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxCarteiraTrabFunc.Controls.Add(this.mskCarteiraTrabalho);
            this.boxCarteiraTrabFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxCarteiraTrabFunc.Location = new System.Drawing.Point(449, 36);
            this.boxCarteiraTrabFunc.Name = "boxCarteiraTrabFunc";
            this.boxCarteiraTrabFunc.Size = new System.Drawing.Size(129, 42);
            this.boxCarteiraTrabFunc.TabIndex = 21;
            this.boxCarteiraTrabFunc.TabStop = false;
            this.boxCarteiraTrabFunc.Text = "Carteira de Trabalho:";
            // 
            // mskCarteiraTrabalho
            // 
            this.mskCarteiraTrabalho.Location = new System.Drawing.Point(6, 16);
            this.mskCarteiraTrabalho.Mask = "0000000/0000";
            this.mskCarteiraTrabalho.Name = "mskCarteiraTrabalho";
            this.mskCarteiraTrabalho.Size = new System.Drawing.Size(82, 20);
            this.mskCarteiraTrabalho.TabIndex = 37;
            // 
            // boxPisFunc
            // 
            this.boxPisFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxPisFunc.Controls.Add(this.txtPis);
            this.boxPisFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxPisFunc.Location = new System.Drawing.Point(322, 36);
            this.boxPisFunc.Name = "boxPisFunc";
            this.boxPisFunc.Size = new System.Drawing.Size(101, 42);
            this.boxPisFunc.TabIndex = 20;
            this.boxPisFunc.TabStop = false;
            this.boxPisFunc.Text = "PIS:";
            // 
            // txtPis
            // 
            this.txtPis.Location = new System.Drawing.Point(6, 16);
            this.txtPis.Name = "txtPis";
            this.txtPis.Size = new System.Drawing.Size(82, 20);
            this.txtPis.TabIndex = 40;
            // 
            // boxDepartamentoFunc
            // 
            this.boxDepartamentoFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxDepartamentoFunc.Controls.Add(this.txtDepartamento);
            this.boxDepartamentoFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxDepartamentoFunc.Location = new System.Drawing.Point(9, 103);
            this.boxDepartamentoFunc.Name = "boxDepartamentoFunc";
            this.boxDepartamentoFunc.Size = new System.Drawing.Size(295, 42);
            this.boxDepartamentoFunc.TabIndex = 23;
            this.boxDepartamentoFunc.TabStop = false;
            this.boxDepartamentoFunc.Text = "Departamento:";
            // 
            // txtDepartamento
            // 
            this.txtDepartamento.Location = new System.Drawing.Point(6, 16);
            this.txtDepartamento.Name = "txtDepartamento";
            this.txtDepartamento.Size = new System.Drawing.Size(273, 20);
            this.txtDepartamento.TabIndex = 50;
            // 
            // boxEmpresaFunc
            // 
            this.boxEmpresaFunc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.boxEmpresaFunc.Controls.Add(this.cbEmpresa);
            this.boxEmpresaFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxEmpresaFunc.Location = new System.Drawing.Point(9, 36);
            this.boxEmpresaFunc.Name = "boxEmpresaFunc";
            this.boxEmpresaFunc.Size = new System.Drawing.Size(295, 42);
            this.boxEmpresaFunc.TabIndex = 19;
            this.boxEmpresaFunc.TabStop = false;
            this.boxEmpresaFunc.Text = "Empresa:";
            // 
            // cbEmpresa
            // 
            this.cbEmpresa.FormattingEnabled = true;
            this.cbEmpresa.Location = new System.Drawing.Point(7, 14);
            this.cbEmpresa.Name = "cbEmpresa";
            this.cbEmpresa.Size = new System.Drawing.Size(272, 21);
            this.cbEmpresa.TabIndex = 0;
            // 
            // boxRgFunc
            // 
            this.boxRgFunc.Controls.Add(this.txtRg);
            this.boxRgFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxRgFunc.Location = new System.Drawing.Point(361, 84);
            this.boxRgFunc.Name = "boxRgFunc";
            this.boxRgFunc.Size = new System.Drawing.Size(101, 40);
            this.boxRgFunc.TabIndex = 12;
            this.boxRgFunc.TabStop = false;
            this.boxRgFunc.Text = "RG:";
            // 
            // txtRg
            // 
            this.txtRg.Location = new System.Drawing.Point(6, 15);
            this.txtRg.Mask = "00,000,000-0";
            this.txtRg.Name = "txtRg";
            this.txtRg.Size = new System.Drawing.Size(82, 20);
            this.txtRg.TabIndex = 23;
            // 
            // boxDataNascFunc
            // 
            this.boxDataNascFunc.Controls.Add(this.txtDataNascimento);
            this.boxDataNascFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxDataNascFunc.Location = new System.Drawing.Point(637, 142);
            this.boxDataNascFunc.Name = "boxDataNascFunc";
            this.boxDataNascFunc.Size = new System.Drawing.Size(127, 39);
            this.boxDataNascFunc.TabIndex = 18;
            this.boxDataNascFunc.TabStop = false;
            this.boxDataNascFunc.Text = "Data de Nascimento:";
            // 
            // txtDataNascimento
            // 
            this.txtDataNascimento.Location = new System.Drawing.Point(6, 13);
            this.txtDataNascimento.Mask = "00/00/0000";
            this.txtDataNascimento.Name = "txtDataNascimento";
            this.txtDataNascimento.Size = new System.Drawing.Size(74, 20);
            this.txtDataNascimento.TabIndex = 28;
            this.txtDataNascimento.ValidatingType = typeof(System.DateTime);
            // 
            // boxTelefoneFunc
            // 
            this.boxTelefoneFunc.Controls.Add(this.maskedTextBox1);
            this.boxTelefoneFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxTelefoneFunc.Location = new System.Drawing.Point(361, 141);
            this.boxTelefoneFunc.Name = "boxTelefoneFunc";
            this.boxTelefoneFunc.Size = new System.Drawing.Size(127, 40);
            this.boxTelefoneFunc.TabIndex = 16;
            this.boxTelefoneFunc.TabStop = false;
            this.boxTelefoneFunc.Text = "Telefone:";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(6, 15);
            this.maskedTextBox1.Mask = "(00)00000-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(82, 20);
            this.maskedTextBox1.TabIndex = 29;
            // 
            // boxEnderecoFunc
            // 
            this.boxEnderecoFunc.Controls.Add(this.txtEnderecoFuncionario);
            this.boxEnderecoFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxEnderecoFunc.Location = new System.Drawing.Point(6, 78);
            this.boxEnderecoFunc.Name = "boxEnderecoFunc";
            this.boxEnderecoFunc.Size = new System.Drawing.Size(295, 46);
            this.boxEnderecoFunc.TabIndex = 11;
            this.boxEnderecoFunc.TabStop = false;
            this.boxEnderecoFunc.Text = "Endereço:";
            // 
            // txtEnderecoFuncionario
            // 
            this.txtEnderecoFuncionario.Location = new System.Drawing.Point(6, 16);
            this.txtEnderecoFuncionario.Name = "txtEnderecoFuncionario";
            this.txtEnderecoFuncionario.Size = new System.Drawing.Size(274, 20);
            this.txtEnderecoFuncionario.TabIndex = 33;
            // 
            // boxEmailFunc
            // 
            this.boxEmailFunc.Controls.Add(this.txtEMail);
            this.boxEmailFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxEmailFunc.Location = new System.Drawing.Point(6, 139);
            this.boxEmailFunc.Name = "boxEmailFunc";
            this.boxEmailFunc.Size = new System.Drawing.Size(295, 42);
            this.boxEmailFunc.TabIndex = 15;
            this.boxEmailFunc.TabStop = false;
            this.boxEmailFunc.Text = "Email:";
            // 
            // txtEMail
            // 
            this.txtEMail.Location = new System.Drawing.Point(6, 16);
            this.txtEMail.Name = "txtEMail";
            this.txtEMail.Size = new System.Drawing.Size(273, 20);
            this.txtEMail.TabIndex = 30;
            // 
            // boxMatriculaFunc
            // 
            this.boxMatriculaFunc.Controls.Add(this.txtMatriculaFuncionario);
            this.boxMatriculaFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxMatriculaFunc.Location = new System.Drawing.Point(590, 86);
            this.boxMatriculaFunc.Name = "boxMatriculaFunc";
            this.boxMatriculaFunc.Size = new System.Drawing.Size(127, 38);
            this.boxMatriculaFunc.TabIndex = 14;
            this.boxMatriculaFunc.TabStop = false;
            this.boxMatriculaFunc.Text = "Matrícula";
            // 
            // txtMatriculaFuncionario
            // 
            this.txtMatriculaFuncionario.Location = new System.Drawing.Point(6, 13);
            this.txtMatriculaFuncionario.Name = "txtMatriculaFuncionario";
            this.txtMatriculaFuncionario.Size = new System.Drawing.Size(82, 20);
            this.txtMatriculaFuncionario.TabIndex = 25;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtSenha);
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.groupBox4.Location = new System.Drawing.Point(6, 187);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(120, 42);
            this.groupBox4.TabIndex = 20;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Senha:";
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(5, 16);
            this.txtSenha.Margin = new System.Windows.Forms.Padding(2);
            this.txtSenha.MaxLength = 8;
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(76, 20);
            this.txtSenha.TabIndex = 10;
            // 
            // boxDataAdmFunc
            // 
            this.boxDataAdmFunc.Controls.Add(this.mskDataAdmissao);
            this.boxDataAdmFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxDataAdmFunc.Location = new System.Drawing.Point(494, 142);
            this.boxDataAdmFunc.Name = "boxDataAdmFunc";
            this.boxDataAdmFunc.Size = new System.Drawing.Size(128, 39);
            this.boxDataAdmFunc.TabIndex = 17;
            this.boxDataAdmFunc.TabStop = false;
            this.boxDataAdmFunc.Text = "Data de Admissão:";
            // 
            // mskDataAdmissao
            // 
            this.mskDataAdmissao.Location = new System.Drawing.Point(6, 13);
            this.mskDataAdmissao.Mask = "00/00/0000";
            this.mskDataAdmissao.Name = "mskDataAdmissao";
            this.mskDataAdmissao.Size = new System.Drawing.Size(75, 20);
            this.mskDataAdmissao.TabIndex = 47;
            this.mskDataAdmissao.ValidatingType = typeof(System.DateTime);
            // 
            // boxCpfFunc
            // 
            this.boxCpfFunc.Controls.Add(this.mskCpf);
            this.boxCpfFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxCpfFunc.Location = new System.Drawing.Point(475, 85);
            this.boxCpfFunc.Name = "boxCpfFunc";
            this.boxCpfFunc.Size = new System.Drawing.Size(101, 39);
            this.boxCpfFunc.TabIndex = 13;
            this.boxCpfFunc.TabStop = false;
            this.boxCpfFunc.Text = "CPF:";
            // 
            // mskCpf
            // 
            this.mskCpf.Location = new System.Drawing.Point(6, 14);
            this.mskCpf.Mask = "000,000,000-00";
            this.mskCpf.Name = "mskCpf";
            this.mskCpf.Size = new System.Drawing.Size(82, 20);
            this.mskCpf.TabIndex = 21;
            // 
            // boxNomeFunc
            // 
            this.boxNomeFunc.Controls.Add(this.txtNomeFuncionario);
            this.boxNomeFunc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.boxNomeFunc.Location = new System.Drawing.Point(6, 33);
            this.boxNomeFunc.Name = "boxNomeFunc";
            this.boxNomeFunc.Size = new System.Drawing.Size(397, 39);
            this.boxNomeFunc.TabIndex = 10;
            this.boxNomeFunc.TabStop = false;
            this.boxNomeFunc.Text = "Nome:";
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.Location = new System.Drawing.Point(6, 14);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(385, 20);
            this.txtNomeFuncionario.TabIndex = 19;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.boxDataAdmFunc);
            this.groupBox2.Controls.Add(this.boxMatriculaFunc);
            this.groupBox2.Controls.Add(this.boxEmailFunc);
            this.groupBox2.Controls.Add(this.boxEnderecoFunc);
            this.groupBox2.Controls.Add(this.boxTelefoneFunc);
            this.groupBox2.Controls.Add(this.boxDataNascFunc);
            this.groupBox2.Controls.Add(this.boxRgFunc);
            this.groupBox2.Controls.Add(this.boxCpfFunc);
            this.groupBox2.Controls.Add(this.boxNomeFunc);
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.groupBox2.Location = new System.Drawing.Point(12, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1042, 244);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dados Pessoais";
            // 
            // btnAddFuncionario
            // 
            this.btnAddFuncionario.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAddFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(104)))), ((int)(((byte)(129)))));
            this.btnAddFuncionario.FlatAppearance.BorderSize = 0;
            this.btnAddFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddFuncionario.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAddFuncionario.Location = new System.Drawing.Point(443, 499);
            this.btnAddFuncionario.Name = "btnAddFuncionario";
            this.btnAddFuncionario.Size = new System.Drawing.Size(145, 54);
            this.btnAddFuncionario.TabIndex = 27;
            this.btnAddFuncionario.Text = "Adicionar";
            this.btnAddFuncionario.UseVisualStyleBackColor = false;
            // 
            // frmAddFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1066, 579);
            this.Controls.Add(this.btnAddFuncionario);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAddFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adicionar Funcionario";
            this.Load += new System.EventHandler(this.frmAddFuncionario_Load);
            this.groupBox1.ResumeLayout(false);
            this.boxSalarioFunc.ResumeLayout(false);
            this.boxSalarioFunc.PerformLayout();
            this.boxCargoFunc.ResumeLayout(false);
            this.boxCargoFunc.PerformLayout();
            this.boxStatusFunc.ResumeLayout(false);
            this.boxCargaFunc.ResumeLayout(false);
            this.boxCargaFunc.PerformLayout();
            this.boxCarteiraTrabFunc.ResumeLayout(false);
            this.boxCarteiraTrabFunc.PerformLayout();
            this.boxPisFunc.ResumeLayout(false);
            this.boxPisFunc.PerformLayout();
            this.boxDepartamentoFunc.ResumeLayout(false);
            this.boxDepartamentoFunc.PerformLayout();
            this.boxEmpresaFunc.ResumeLayout(false);
            this.boxRgFunc.ResumeLayout(false);
            this.boxRgFunc.PerformLayout();
            this.boxDataNascFunc.ResumeLayout(false);
            this.boxDataNascFunc.PerformLayout();
            this.boxTelefoneFunc.ResumeLayout(false);
            this.boxTelefoneFunc.PerformLayout();
            this.boxEnderecoFunc.ResumeLayout(false);
            this.boxEnderecoFunc.PerformLayout();
            this.boxEmailFunc.ResumeLayout(false);
            this.boxEmailFunc.PerformLayout();
            this.boxMatriculaFunc.ResumeLayout(false);
            this.boxMatriculaFunc.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.boxDataAdmFunc.ResumeLayout(false);
            this.boxDataAdmFunc.PerformLayout();
            this.boxCpfFunc.ResumeLayout(false);
            this.boxCpfFunc.PerformLayout();
            this.boxNomeFunc.ResumeLayout(false);
            this.boxNomeFunc.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tBempresaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBempresaBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox boxSalarioFunc;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.GroupBox boxCargoFunc;
        private System.Windows.Forms.TextBox txtCargoFunc;
        private System.Windows.Forms.GroupBox boxStatusFunc;
        private System.Windows.Forms.ComboBox cboStatus;
        private System.Windows.Forms.GroupBox boxCargaFunc;
        private System.Windows.Forms.MaskedTextBox txtCargaHorariaSemanal;
        private System.Windows.Forms.GroupBox boxCarteiraTrabFunc;
        private System.Windows.Forms.MaskedTextBox mskCarteiraTrabalho;
        private System.Windows.Forms.GroupBox boxPisFunc;
        private System.Windows.Forms.MaskedTextBox txtPis;
        private System.Windows.Forms.GroupBox boxDepartamentoFunc;
        private System.Windows.Forms.TextBox txtDepartamento;
        private System.Windows.Forms.GroupBox boxEmpresaFunc;
        private System.Windows.Forms.ComboBox cbEmpresa;
        private System.Windows.Forms.GroupBox boxRgFunc;
        private System.Windows.Forms.MaskedTextBox txtRg;
        private System.Windows.Forms.GroupBox boxDataNascFunc;
        private System.Windows.Forms.MaskedTextBox txtDataNascimento;
        private System.Windows.Forms.GroupBox boxTelefoneFunc;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.GroupBox boxEnderecoFunc;
        private System.Windows.Forms.TextBox txtEnderecoFuncionario;
        private System.Windows.Forms.GroupBox boxEmailFunc;
        private System.Windows.Forms.TextBox txtEMail;
        private System.Windows.Forms.GroupBox boxMatriculaFunc;
        private System.Windows.Forms.TextBox txtMatriculaFuncionario;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.GroupBox boxDataAdmFunc;
        private System.Windows.Forms.MaskedTextBox mskDataAdmissao;
        private System.Windows.Forms.GroupBox boxCpfFunc;
        private System.Windows.Forms.MaskedTextBox mskCpf;
        private System.Windows.Forms.GroupBox boxNomeFunc;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.BindingSource tBempresaBindingSource;
        private System.Windows.Forms.BindingSource tBempresaBindingSource1;
        private System.Windows.Forms.Button btnAddFuncionario;
    }
}